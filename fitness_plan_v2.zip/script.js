function showDays(level) {
  document.getElementById('levels-page').style.display = 'none';
  document.getElementById('days-page').style.display = 'block';
  document.getElementById('level-title').innerText = level;
  document.getElementById('workout-tasks').innerHTML = '';
}
function backToLevels() {
  document.getElementById('days-page').style.display = 'none';
  document.getElementById('levels-page').style.display = 'block';
}
function showWorkouts(day) {
  const workoutDiv = document.getElementById('workout-tasks');
  workoutDiv.innerHTML = `
    <div class="workout-card">
      <h3>Day ${day} Workout</h3>
      <div class="exercise">
        <img src="https://via.placeholder.com/400x250?text=Exercise+1" alt="Exercise 1">
        <div class="exercise-text">
          <p><strong>Exercise 1:</strong> Do 15 squats. Keep your back straight and push through your heels.</p>
        </div>
      </div>
      <div class="exercise">
        <img src="https://via.placeholder.com/400x250?text=Exercise+2" alt="Exercise 2">
        <div class="exercise-text">
          <p><strong>Exercise 2:</strong> Perform 20 push-ups. Keep your body aligned and avoid sagging hips.</p>
        </div>
      </div>
    </div>
  `;
  workoutDiv.scrollIntoView({ behavior: 'smooth' });
}